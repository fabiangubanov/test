Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$heartDir = Join-Path $root "assets\minecraft\textures\gui\sprites\hud\heart"

function New-Bitmap($width, $height) {
    return New-Object System.Drawing.Bitmap $width, $height, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
}

function Save-Png($bitmap, $path) {
    $bitmap.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bitmap.Dispose()
}

function Color-Hex($hex) {
    return [System.Drawing.ColorTranslator]::FromHtml($hex)
}

$mask = @(
    "011001100",
    "111111110",
    "111111110",
    "111111110",
    "011111100",
    "001111000",
    "000110000",
    "000000000",
    "000000000"
)

$purple = @(
    (Color-Hex "#f2c6ff"),
    (Color-Hex "#d983ff"),
    (Color-Hex "#b13cff"),
    (Color-Hex "#7b1fd1")
)
$outlinePurple = Color-Hex "#3b0b5f"
$gray = @(
    (Color-Hex "#8b8b8b"),
    (Color-Hex "#6c6c6c"),
    (Color-Hex "#535353"),
    (Color-Hex "#3f3f3f")
)
$outlineGray = Color-Hex "#252525"
$transparent = [System.Drawing.Color]::FromArgb(0, 0, 0, 0)

function Test-Mask($x, $y) {
    if ($x -lt 0 -or $x -ge 9 -or $y -lt 0 -or $y -ge 9) {
        return $false
    }
    return $mask[$y][$x] -eq '1'
}

function Test-Outline($x, $y) {
    foreach ($offset in @(@(-1, 0), @(1, 0), @(0, -1), @(0, 1))) {
        if (-not (Test-Mask ($x + $offset[0]) ($y + $offset[1]))) {
            return $true
        }
    }
    return $false
}

function New-HeartSprite($mode) {
    $bitmap = New-Bitmap 9 9
    for ($y = 0; $y -lt 9; $y++) {
        for ($x = 0; $x -lt 9; $x++) {
            $bitmap.SetPixel($x, $y, $transparent)
            if (-not (Test-Mask $x $y)) {
                continue
            }
            $isOutline = Test-Outline $x $y
            if ($mode -eq "container") {
                $shade = [Math]::Min(3, [Math]::Max(0, [int][Math]::Floor(($x + $y) / 4)))
                $bitmap.SetPixel($x, $y, $(if ($isOutline) { $outlineGray } else { $gray[$shade] }))
                continue
            }
            if ($mode -eq "half" -and $x -gt 4) {
                continue
            }
            $shade = [Math]::Min(3, [Math]::Max(0, [int][Math]::Floor(($x + $y) / 4)))
            $bitmap.SetPixel($x, $y, $(if ($isOutline) { $outlinePurple } else { $purple[$shade] }))
        }
    }
    return $bitmap
}

$fullNames = @(
    "full.png", "full_blinking.png",
    "hardcore_full.png", "hardcore_full_blinking.png",
    "poisoned_full.png", "poisoned_full_blinking.png",
    "poisoned_hardcore_full.png", "poisoned_hardcore_full_blinking.png",
    "withered_full.png", "withered_full_blinking.png",
    "withered_hardcore_full.png", "withered_hardcore_full_blinking.png",
    "frozen_full.png", "frozen_full_blinking.png",
    "frozen_hardcore_full.png", "frozen_hardcore_full_blinking.png",
    "absorbing_full.png", "absorbing_full_blinking.png",
    "absorbing_hardcore_full.png", "absorbing_hardcore_full_blinking.png",
    "vehicle_full.png"
)

$halfNames = @(
    "half.png", "half_blinking.png",
    "hardcore_half.png", "hardcore_half_blinking.png",
    "poisoned_half.png", "poisoned_half_blinking.png",
    "poisoned_hardcore_half.png", "poisoned_hardcore_half_blinking.png",
    "withered_half.png", "withered_half_blinking.png",
    "withered_hardcore_half.png", "withered_hardcore_half_blinking.png",
    "frozen_half.png", "frozen_half_blinking.png",
    "frozen_hardcore_half.png", "frozen_hardcore_half_blinking.png",
    "absorbing_half.png", "absorbing_half_blinking.png",
    "absorbing_hardcore_half.png", "absorbing_hardcore_half_blinking.png",
    "vehicle_half.png"
)

$containerNames = @(
    "container.png", "container_blinking.png",
    "container_hardcore.png", "container_hardcore_blinking.png",
    "vehicle_container.png"
)

foreach ($name in $fullNames) {
    Save-Png (New-HeartSprite "full") (Join-Path $heartDir $name)
}
foreach ($name in $halfNames) {
    Save-Png (New-HeartSprite "half") (Join-Path $heartDir $name)
}
foreach ($name in $containerNames) {
    Save-Png (New-HeartSprite "container") (Join-Path $heartDir $name)
}

$icon = New-Bitmap 64 64
for ($y = 0; $y -lt 64; $y++) {
    for ($x = 0; $x -lt 64; $x++) {
        $icon.SetPixel($x, $y, [System.Drawing.Color]::FromArgb(255, 20, 12, 28))
    }
}
for ($i = 0; $i -lt 4; $i++) {
    $heart = New-HeartSprite "full"
    $gfx = [System.Drawing.Graphics]::FromImage($icon)
    $gfx.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
    $gfx.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
    $gfx.DrawImage($heart, 5 + ($i * 15), 22, 14, 14)
    $gfx.Dispose()
    $heart.Dispose()
}
Save-Png $icon (Join-Path $root "pack.png")

$fontDir = Join-Path $root "assets\purplehearts\textures\font"
$font = New-Bitmap 18 18
$fontGraphics = [System.Drawing.Graphics]::FromImage($font)
$fontGraphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$fontGraphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
$fontPalette = @(
    "#f2c6ff",
    "#d983ff",
    "#b13cff",
    "#7b1fd1"
)
for ($i = 0; $i -lt 4; $i++) {
    $variant = New-HeartSprite "full"
    $shade = Color-Hex $fontPalette[$i]
    for ($y = 0; $y -lt 9; $y++) {
        for ($x = 0; $x -lt 9; $x++) {
            $pixel = $variant.GetPixel($x, $y)
            if ($pixel.A -eq 0) {
                continue
            }
            $variant.SetPixel($x, $y, [System.Drawing.Color]::FromArgb($pixel.A, $shade.R, $shade.G, $shade.B))
        }
    }
    $dx = ($i % 2) * 9
    $dy = [int]([math]::Floor($i / 2)) * 9
    $fontGraphics.DrawImage($variant, $dx, $dy, 9, 9)
    $variant.Dispose()
}
$fontGraphics.Dispose()
Save-Png $font (Join-Path $fontDir "hearts.png")
